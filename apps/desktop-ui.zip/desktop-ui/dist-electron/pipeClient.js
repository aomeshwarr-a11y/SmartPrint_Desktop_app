"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentPipeClient = exports.AgentPipeClient = void 0;
const net = __importStar(require("node:net"));
const node_crypto_1 = require("node:crypto");
/**
 * Client-side half of the named pipe IPC protocol implemented in
 * services/desktop-agent/SmartPrinter.Agent/Ipc/NamedPipeServer.cs. This runs in
 * Electron's MAIN process (never the renderer) - the renderer only ever talks to this
 * class through the secure preload bridge (see preload.ts), which is the standard
 * "contextIsolation + no direct Node/net access from the page" Electron security model.
 *
 * Protocol: one JSON object per line, both directions. Requests carry a client-generated
 * `id`; responses echo it back so concurrent calls can be matched even though the pipe is
 * a single duplex byte stream per connection.
 */
const PIPE_NAME = process.platform === "win32" ? "\\\\.\\pipe\\SmartPrinterAgentPipe" : "/tmp/smartprinter-agent-dev.sock";
class AgentPipeClient {
    constructor() {
        this.socket = null;
        this.buffer = "";
        this.pending = new Map();
        this.connecting = null;
        this.reconnectDelayMs = 1000;
    }
    async call(command, payload, timeoutMs = 15000) {
        await this.ensureConnected();
        return new Promise((resolve, reject) => {
            const id = (0, node_crypto_1.randomUUID)();
            const timeout = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error(`IPC call '${command}' timed out after ${timeoutMs}ms - is SmartPrinter.Agent running?`));
            }, timeoutMs);
            this.pending.set(id, { resolve, reject, timeout });
            const request = JSON.stringify({ id, command, payload }) + "\n";
            this.socket.write(request, (err) => {
                if (err) {
                    clearTimeout(timeout);
                    this.pending.delete(id);
                    reject(err);
                }
            });
        });
    }
    ensureConnected() {
        if (this.socket && !this.socket.destroyed) {
            return Promise.resolve();
        }
        if (this.connecting) {
            return this.connecting;
        }
        this.connecting = new Promise((resolve, reject) => {
            const socket = net.createConnection(PIPE_NAME);
            const onError = (err) => {
                this.connecting = null;
                reject(new Error(`Could not connect to SmartPrinter.Agent named pipe (${PIPE_NAME}): ${err.message}`));
            };
            socket.once("error", onError);
            socket.once("connect", () => {
                socket.removeListener("error", onError);
                socket.on("data", (chunk) => this.onData(chunk));
                socket.on("close", () => this.onClose());
                socket.on("error", (err) => this.onClose(err));
                this.socket = socket;
                this.connecting = null;
                resolve();
            });
        });
        return this.connecting;
    }
    onData(chunk) {
        this.buffer += chunk.toString("utf8");
        let newlineIndex;
        while ((newlineIndex = this.buffer.indexOf("\n")) >= 0) {
            const line = this.buffer.slice(0, newlineIndex);
            this.buffer = this.buffer.slice(newlineIndex + 1);
            if (!line.trim())
                continue;
            try {
                const response = JSON.parse(line);
                const pending = this.pending.get(response.id);
                if (!pending)
                    continue;
                this.pending.delete(response.id);
                clearTimeout(pending.timeout);
                if (response.success) {
                    pending.resolve(response.data);
                }
                else {
                    pending.reject(new Error(response.error ?? "Unknown agent error."));
                }
            }
            catch {
                // Ignore malformed lines rather than crashing the whole IPC channel.
            }
        }
    }
    onClose(err) {
        this.socket = null;
        for (const [, pending] of this.pending) {
            clearTimeout(pending.timeout);
            pending.reject(err ?? new Error("Connection to SmartPrinter.Agent was closed."));
        }
        this.pending.clear();
    }
}
exports.AgentPipeClient = AgentPipeClient;
exports.agentPipeClient = new AgentPipeClient();
