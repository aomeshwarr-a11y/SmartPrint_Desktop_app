"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
/**
 * The ONLY surface the renderer (React app) can use to reach outside its sandbox. This
 * follows Electron's recommended contextBridge pattern: nothing here gives the page raw
 * ipcRenderer, Node's require, or filesystem access - only two narrow async functions.
 */
electron_1.contextBridge.exposeInMainWorld("smartprinter", {
    callAgent: (command, payload) => electron_1.ipcRenderer.invoke("agent:call", command, payload),
    openExternal: (url) => electron_1.ipcRenderer.invoke("shell:openExternal", url),
    onUpdateDownloaded: (callback) => {
        electron_1.ipcRenderer.on("update:downloaded", () => callback());
    },
});
