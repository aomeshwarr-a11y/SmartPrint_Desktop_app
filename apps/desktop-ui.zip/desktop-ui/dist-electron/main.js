"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path = __importStar(require("node:path"));
const electron_updater_1 = require("electron-updater");
const pipeClient_1 = require("./pipeClient");
const isDev = process.env.NODE_ENV === "development";
// Allowlist for any external link the renderer asks to open (e.g. "view invoice",
// "SmartPrinter support") - prevents the renderer from using shell.openExternal as an
// arbitrary command/URL launcher. See docs/SECURITY.md "safe external URL handling".
const ALLOWED_EXTERNAL_HOSTS = new Set(["smartprinter.in", "www.smartprinter.in", "supabase.com"]);
let mainWindow = null;
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1280,
        height: 820,
        minWidth: 1024,
        minHeight: 700,
        backgroundColor: "#faf6ee",
        title: "SmartPrinter Desktop",
        webPreferences: {
            // The three settings below are the non-negotiable core of Electron security:
            // the renderer gets NO direct Node.js or Electron API access. Everything it
            // can do is exposed deliberately and narrowly through preload.ts.
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            preload: path.join(__dirname, "preload.js"),
        },
    });
    if (isDev) {
        mainWindow.loadURL("http://localhost:5173");
        mainWindow.webContents.openDevTools({ mode: "detach" });
    }
    else {
        mainWindow.loadFile(path.join(__dirname, "..", "dist", "index.html"));
    }
    // Never allow the renderer to spawn arbitrary new windows/webviews.
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        tryOpenExternal(url);
        return { action: "deny" };
    });
    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}
function tryOpenExternal(url) {
    try {
        const parsed = new URL(url);
        if (parsed.protocol === "https:" && ALLOWED_EXTERNAL_HOSTS.has(parsed.hostname)) {
            void electron_1.shell.openExternal(url);
        }
    }
    catch {
        // Malformed URL - silently ignore rather than risk shell.openExternal on garbage input.
    }
}
electron_1.app.whenReady().then(() => {
    createWindow();
    if (!isDev) {
        electron_updater_1.autoUpdater.checkForUpdatesAndNotify().catch((err) => {
            console.error("Auto-update check failed:", err);
        });
    }
    electron_1.app.on("activate", () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0)
            createWindow();
    });
});
electron_1.app.on("window-all-closed", () => {
    // Closing the UI window must NEVER stop print jobs - the background agent is a
    // separate OS process (a Windows Service) and keeps running regardless. This only
    // quits the Electron shell itself.
    if (process.platform !== "darwin")
        electron_1.app.quit();
});
// ---------------- IPC bridge: renderer (via preload) -> main -> named pipe -> agent ----------------
// Every channel here is a 1:1 forward to a specific, known agent command - the renderer
// can never send an arbitrary pipe command string (see preload.ts for the same narrow
// whitelist enforced on the renderer side too, defense in depth).
const AGENT_CALL_CHANNEL = "agent:call";
electron_1.ipcMain.handle(AGENT_CALL_CHANNEL, async (_event, command, payload) => {
    return pipeClient_1.agentPipeClient.call(command, payload);
});
electron_1.ipcMain.handle("shell:openExternal", (_event, url) => {
    tryOpenExternal(url);
});
electron_updater_1.autoUpdater.on("update-downloaded", () => {
    mainWindow?.webContents.send("update:downloaded");
});
